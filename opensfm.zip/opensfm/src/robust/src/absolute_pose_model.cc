#include "robust/absolute_pose_model.h"

const int AbsolutePose::MINIMAL_SAMPLES;
