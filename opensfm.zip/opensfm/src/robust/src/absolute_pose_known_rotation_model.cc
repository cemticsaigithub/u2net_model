#include "robust/absolute_pose_known_rotation_model.h"

const int AbsolutePoseKnownRotation::MINIMAL_SAMPLES;
