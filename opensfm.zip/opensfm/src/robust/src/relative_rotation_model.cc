#include "robust/relative_rotation_model.h"

const int RelativeRotation::MINIMAL_SAMPLES;
