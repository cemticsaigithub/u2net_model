# pyre-unsafe
from opensfm import feature_loading


instance = feature_loading.FeatureLoader()
